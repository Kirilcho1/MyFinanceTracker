﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Globalization;

namespace MyFinanceTracker.Models.DataTransferObjects
{
    public class GoalDTO
    {
        public int GoalId { get; set; }
        public string Name { get; set; }
        public decimal TargetAmount { get; set; }
        public decimal CurrentAmount { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string AccountName { get; set; }
        public string GoalType { get; set; }
        public string TargetAmountWithCurrency { get; set; }
        public string CurrentAmountWithCurrency { get; set; }

        [NotMapped]
        public string StartDateFormatted
        {
            get { return StartDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture); }
        }

        [NotMapped]
        public string EndDateFormatted
        {
            get { return EndDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture); }
        }

    }
}