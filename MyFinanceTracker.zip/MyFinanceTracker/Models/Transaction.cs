﻿using MyFinanceTracker.Models;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Newtonsoft.Json;
using System.Globalization;

namespace MyFinanceTracker.Models
{
    public class Transaction
    {
        [Key]
        public int TransactionId { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Please select a Category!")]
        public int CategoryId { get; set; }
        public Category Category { get; set; }

        [Range(1.0, (double)decimal.MaxValue, ErrorMessage = "The Amount should not be zero!")]
public decimal Amount { get; set; }

        [Column(TypeName = "nvarchar(255)")]
        public string? Note { get; set; }

        public DateTime Date { get; set; } = DateTime.Now;

        [NotMapped]
        public string? CategoryTitleWithIcon
        {
            get
            {
                return Category == null ? "" : Category.Icon + " " + Category.Title;
            }
        }

        [NotMapped]
        public string? AmountWithCurrency
        {
            get
            {
                var cultureInfo = new CultureInfo("en-GB")
                {
                    NumberFormat = { CurrencySymbol = "$" }
                };
                return ((Category == null || Category.Type == "Expense") ? "- " : "+ ") + Amount.ToString("C0", cultureInfo);
            }
        }

        public int UserId { get; set; }
        public User User { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Please select an Account!")]
        public int? AccountId { get; set; }
        [JsonIgnore]
        public Account Account { get; set; }
        public int? GoalId { get; set; }
        public Goal? Goal { get; set; }
        [NotMapped]
        public string AccountName => Account?.Name ?? "No Account";

    }
}