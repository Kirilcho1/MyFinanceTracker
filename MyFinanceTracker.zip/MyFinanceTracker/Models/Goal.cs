﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace MyFinanceTracker.Models
{
    public class Goal
    {
        [Key]
        public int GoalId { get; set; }

        [Column(TypeName = "nvarchar(255)")]
        public string Name { get; set; }

        public decimal TargetAmount { get; set; }
        public decimal CurrentAmount { get; set; } = 0;

        public DateTime StartDate { get; set; } = DateTime.Now;

        public DateTime EndDate { get; set; } = DateTime.Now;


        public int UserId { get; set; }
        [JsonIgnore]
        public User User { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Please select an Account!")]
        public int AccountId { get; set; }
        [JsonIgnore]
        public Account Account { get; set; }

        [JsonIgnore]
        public ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();

        [Column(TypeName = "nvarchar(50)")]
        public string GoalType { get; set; }



    }
}