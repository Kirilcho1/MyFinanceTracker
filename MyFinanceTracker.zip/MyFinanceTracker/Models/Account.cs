﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using System.Globalization;

namespace MyFinanceTracker.Models
{
    public class Account
    {
        [Key]
        public int AccountId { get; set; }

        [Column(TypeName = "nvarchar(255)")]
        public string Name { get; set; }

        [Column(TypeName = "nvarchar(255)")]
        public string AccountType { get; set; }

        public decimal Balance { get; set; } = 0;

        public int UserId { get; set; }
        public User User { get; set; }

        public ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();

        [JsonIgnore]
        public ICollection<Goal> Goals { get; set; } = new List<Goal>();

        [NotMapped]
        public string BalanceWithCurrency
        {
            get
            {
                var cultureInfo = new CultureInfo("en-GB")
                {
                    NumberFormat = { CurrencySymbol = "$" }
                };
                return Balance.ToString("C0", cultureInfo);
            }
        }
    }
}