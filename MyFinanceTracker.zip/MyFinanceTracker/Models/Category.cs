﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyFinanceTracker.Models
{
    public class Category
    {
        [Key]
        public int CategoryId { get; set; }

        [Required(ErrorMessage = "The Title field is required.")]
        [Column(TypeName = "nvarchar(255)")]
        public string Title { get; set; }

        [Column(TypeName = "nvarchar(255)")]
        public string Icon { get; set; } = "";

        [Column(TypeName = "nvarchar(255)")]
        public string Type { get; set; } = "Expense";

        public int UserId { get; set; }

        [ForeignKey("UserId")]
        public User User { get; set; }
        [NotMapped]
        public string? TitleWithIcon
        {
            get
            {
                return this.Icon + " " + this.Title;
            }
        }
        [NotMapped]


        [JsonIgnore]
        public ICollection<Transaction> Transactions { get; set; } = new HashSet<Transaction>();
    }
}