﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Globalization;

namespace MyFinanceTracker.Models
{
    public class Investment
    {
        [Key]
        public int InvestmentId { get; set; }

        [Column(TypeName = "nvarchar(255)")]
        public string Name { get; set; }

        public decimal TargetAmount { get; set; }
        public decimal CurrentAmount { get; set; }

        [NotMapped]
        public string TargetAmountWithCurrency
        {
            get
            {
                var cultureInfo = new CultureInfo("en-GB")
                {
                    NumberFormat = { CurrencySymbol = "$" }
                };
                return TargetAmount.ToString("C0", cultureInfo);
            }
        }

        [NotMapped]
        public string CurrentAmountWithCurrency
        {
            get
            {
                var cultureInfo = new CultureInfo("en-GB")
                {
                    NumberFormat = { CurrencySymbol = "$" }
                };
                return CurrentAmount.ToString("C0", cultureInfo);
            }
        }
        [NotMapped]
        public string CreatedAtFormatted
        {
            get { return CreatedAt.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture); }
        }
        public DateTime CreatedAt { get; set; }

        public int UserId { get; set; }
        public User User { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Please select an Account!")]
        public int? AccountId { get; set; }
        public Account Account { get; set; }
    }
}