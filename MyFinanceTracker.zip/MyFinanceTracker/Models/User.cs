﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyFinanceTracker.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }

        [Column(TypeName = "nvarchar(255)")]
        public string Username { get; set; }

        [Column(TypeName = "nvarchar(255)")]
        public string Password { get; set; }

        [Column(TypeName = "nvarchar(255)")]
        public string Email { get; set; }


        public ICollection<Transaction> Transactions { get; set; }


        public ICollection<Category> Categories { get; set; }


        public ICollection<Account> Accounts { get; set; }


        public ICollection<Investment> Investments { get; set; }

        public ICollection<Goal> Goals { get; set; } = new HashSet<Goal>();



        public User()
        {
            Transactions = new HashSet<Transaction>();
            Categories = new HashSet<Category>();
            Accounts = new HashSet<Account>();
            Investments = new HashSet<Investment>();
            Goals = new HashSet<Goal>();

        }
    }
}