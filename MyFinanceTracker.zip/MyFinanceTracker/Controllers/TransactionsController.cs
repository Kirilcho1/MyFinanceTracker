﻿using System;
using System.Linq;
using System.Threading.Tasks;
using MyFinanceTracker.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace MyFinanceTracker.Controllers
{
    public class TransactionsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<TransactionsController> _logger;

        public TransactionsController(ApplicationDbContext context, ILogger<TransactionsController> logger)
        {
            _context = context;
            _logger = logger;
        }


        public async Task<IActionResult> Index()
        {
            var userId = GetUserId();
            var transactions = _context.Transactions
                .Include(t => t.Category)
                .Include(t => t.Account)
                .Where(t => t.UserId == userId);
            return View(await transactions.ToListAsync());
        }

        public IActionResult Create()
        {
            PopulateCategories();
            PopulateAccounts();
            return View(new Transaction());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Transaction transaction)
        {
            ModelState.Remove("User");
            ModelState.Remove("Category");
            ModelState.Remove("Account");

            if (ModelState.IsValid)
            {
                try
                {
                    var userId = GetUserId();
                    transaction.UserId = userId;

                    var category = await _context.Categories.FindAsync(transaction.CategoryId);
                    if (category == null)
                    {
                        ModelState.AddModelError("Category", "The category is not found.");
                        _logger.LogWarning("Category not found.");
                        PopulateCategories();
                        PopulateAccounts();
                        return View(transaction);
                    }

                    var account = await _context.Accounts.FindAsync(transaction.AccountId);
                    if (account == null || account.UserId != userId)
                    {
                        ModelState.AddModelError("Account", "The account is not found.");
                        _logger.LogWarning("Account not found.");
                        PopulateCategories();
                        PopulateAccounts();
                        return View(transaction);
                    }

                    if (category.Type == "Expense")
                    {
                        if (account.Balance < transaction.Amount)
                        {
                            ModelState.AddModelError("Amount", "Not enough balance in the account.");
                            PopulateCategories();
                            PopulateAccounts();
                            return View(transaction);
                        }
                        account.Balance -= transaction.Amount;
                    }
                    else if (category.Type == "Income")
                    {
                        account.Balance += transaction.Amount;
                    }

                    var existingGoal = await _context.Goals
                        .FirstOrDefaultAsync(g => g.AccountId == transaction.AccountId
                                                  && g.GoalType == category.Type
                                                  && g.UserId == userId
                                                  && g.StartDate <= transaction.Date
                                                  && g.EndDate >= transaction.Date);

                    if (existingGoal != null)
                    {
                        transaction.GoalId = existingGoal.GoalId;

                        if (category.Type == "Income")
                        {
                            existingGoal.CurrentAmount += transaction.Amount;
                        }
                        else if (category.Type == "Expense")
                        {
                            existingGoal.CurrentAmount -= transaction.Amount;
                        }

                        _context.Update(existingGoal);
                    }

                    _context.Add(transaction);
                    _context.Update(account);
                    await _context.SaveChangesAsync();

                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "An error occurred while creating the transaction.");
                    ModelState.AddModelError(string.Empty, "An error occurred while processing your request. Please try again.");
                }
            }

            PopulateCategories();
            PopulateAccounts();
            return View(transaction);
        }


        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var transaction = await _context.Transactions
                .Include(t => t.Category)
                .Include(t => t.Account)
                .FirstOrDefaultAsync(t => t.TransactionId == id);

            if (transaction == null || transaction.UserId != GetUserId())
            {
                return NotFound("The transaction is not found or user does not have permission.");
            }

            if (transaction.Category.Type == "Expense")
            {
                transaction.Account.Balance += transaction.Amount;
            }
            else if (transaction.Category.Type == "Income")
            {
                transaction.Account.Balance -= transaction.Amount;
            }

            if (transaction.GoalId.HasValue)
            {
                var goal = await _context.Goals.FindAsync(transaction.GoalId.Value);
                if (goal != null)
                {
                    if (transaction.Category.Type == "Income")
                    {
                        goal.CurrentAmount -= transaction.Amount;
                    }
                    else if (transaction.Category.Type == "Expense")
                    {
                        goal.CurrentAmount += transaction.Amount;
                    }
                    _context.Update(goal);
                }
            }

            _context.Transactions.Remove(transaction);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        [NonAction]
        private void PopulateCategories()
        {
            var userId = GetUserId();
            var categories = _context.Categories.Where(c => c.UserId == userId).ToList();
            Category defaultCategory = new Category()
            {
                CategoryId = 0,
                Title = "Choose a Category"
            };
            categories.Insert(0, defaultCategory);
            ViewBag.Categories = categories;
        }

        [NonAction]
        private void PopulateAccounts()
        {
            var userId = GetUserId();
            var accounts = _context.Accounts.Where(a => a.UserId == userId).ToList();
            Account defaultAccount = new Account()
            {
                AccountId = 0,
                Name = "Choose an Account"
            };
            accounts.Insert(0, defaultAccount);
            ViewBag.Accounts = accounts;
        }

        [NonAction]
        private void PopulateGoals()
        {
            var userId = GetUserId();
            var goals = _context.Goals
                .Where(g => g.UserId == userId)
                .ToList();

            Goal defaultGoal = new Goal()
            {
                GoalId = 0,
                Name = "Choose a Goal"
            };

            goals.Insert(0, defaultGoal);
            ViewBag.Goals = goals;
        }


        [NonAction]
        private int GetUserId()
        {
            var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(userIdClaim))
            {
                _logger.LogError("Failed to retrieve UserId. User might not be logged in.");
                throw new InvalidOperationException("The User ID claim is not found or the user is not authenticated.");
            }

            if (int.TryParse(userIdClaim, out int userId))
            {
                return userId;
            }
            else
            {
                _logger.LogError("Failed to parse UserId from claim.");
                throw new InvalidOperationException("User ID claim not found or invalid.");
            }
        }
    }
}