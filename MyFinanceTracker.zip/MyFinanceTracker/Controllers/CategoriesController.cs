﻿using System;
using System.Linq;
using System.Threading.Tasks;
using MyFinanceTracker.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace MyFinanceTracker.Controllers
{
    public class CategoriesController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<CategoriesController> _logger;

        public CategoriesController(ApplicationDbContext context, ILogger<CategoriesController> logger)
        {
            _context = context;
            _logger = logger;
        }


        public async Task<IActionResult> Index()
        {
            var userId = GetUserId();
            var categories = await _context.Categories
                .Where(c => c.UserId == userId)
                .ToListAsync();
            return View(categories);
        }


        public IActionResult Create()
        {

            return View(new Category());


        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Category category)
        {
            var userId = GetUserId();

            ModelState.Remove("User");

            if (ModelState.IsValid)
            {
                try
                {
                    category.UserId = userId;


                    var duplicateCategory = await _context.Categories
                        .FirstOrDefaultAsync(c => c.Title == category.Title && c.UserId == userId);

                    if (duplicateCategory != null)
                    {
                        ModelState.AddModelError("Title", "This category is already created.");
                        return View(category);
                    }


                    _context.Add(category);

                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, $"An error occurred while creating the category for user ID {userId}.");
                    ModelState.AddModelError(string.Empty, "An error occurred while processing your request. Please try again.");
                }
            }
            else
            {
                _logger.LogWarning("ModelState is invalid.");
                foreach (var modelStateKey in ModelState.Keys)
                {
                    var value = ModelState[modelStateKey];
                    foreach (var error in value.Errors)
                    {
                        _logger.LogWarning($"Key: {modelStateKey}, Error: {error.ErrorMessage}");
                    }
                }
            }

            return View(category);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                var userId = GetUserId();
                var category = await _context.Categories
                    .FirstOrDefaultAsync(m => m.CategoryId == id && m.UserId == userId);

                if (category == null)
                {
                    return NotFound();
                }


                var isInUse = await _context.Transactions
                    .AnyAsync(t => t.CategoryId == id && t.UserId == userId);

                if (isInUse)
                {

                    _logger.LogWarning("Attempted to delete category with ID {CategoryId} that is in use.", id);

                    var errorModel = new ErrorViewModel
                    {
                        Message = "The category cannot be deleted because one or more transactions are already using it."
                    };
                    return View("Error", errorModel);
                }

                _context.Categories.Remove(category);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while deleting the category with ID {id}.");
                var errorModel = new ErrorViewModel
                {
                    Message = "An error occurred while processing your request. Please try again later."
                };
                return View("Error", errorModel);
            }
        }

        [NonAction]
        private int GetUserId()
        {
            var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(userIdClaim))
            {
                _logger.LogError("Failed to retrieve UserId. User might not be logged in.");
                throw new InvalidOperationException("User ID claim not found or user is not authenticated.");
            }

            if (int.TryParse(userIdClaim, out int userId))
            {
                return userId;
            }
            else
            {
                _logger.LogError("Failed to parse UserId from claim.");
                throw new InvalidOperationException("The User ID claim is not found or invalid.");
            }
        }
    }
}