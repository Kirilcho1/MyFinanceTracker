﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyFinanceTracker.Models;
using MyFinanceTracker.ViewModels;
using System.Security.Claims;
using System.Threading.Tasks;

namespace MyFinanceTracker.Controllers
{
    public class UserController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<UserController> _logger;

        public UserController(ApplicationDbContext context, ILogger<UserController> logger)
        {
            _context = context;
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                _logger.LogInformation("Model state is valid. Attempting to log in user with email: {Email}", model.Email);

                var user = await _context.Users
                    .FirstOrDefaultAsync(u => u.Email == model.Email && u.Password == model.Password);

                if (user != null)
                {
                    _logger.LogInformation("User found in the database with email: {Email}", model.Email);

                    var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
                        new Claim(ClaimTypes.Name, user.Username),
                        new Claim(ClaimTypes.Email, user.Email)
                    };

                    var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    var principal = new ClaimsPrincipal(identity);

                    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

                    _logger.LogInformation("The User {Email} is logged in successfully.", model.Email);

                    return RedirectToAction("Index", "Dashboard");
                }
                else
                {
                    _logger.LogWarning("Invalid login attempt. The user with email {Email} is not found or password is incorrect.", model.Email);
                    ModelState.AddModelError("", "Invalid login attempt.");
                }
            }
            else
            {
                _logger.LogWarning("Model state is invalid. Errors: {Errors}", string.Join(", ", ModelState.Values.SelectMany(v => v.Errors.Select(e => e.ErrorMessage))));
            }

            return View(model);
        }


        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {

                if (await _context.Users.AnyAsync(u => u.Email == model.Email))
                {
                    ModelState.AddModelError("Email", "The Email is already in use.");
                    return View(model);
                }


                var user = new User
                {
                    Username = model.Username,
                    Password = model.Password,
                    Email = model.Email
                };

                _context.Add(user);
                await _context.SaveChangesAsync();

                return RedirectToAction("Login");
            }

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", "User");
        }

        [HttpGet]
        public IActionResult Change()
        {
            return View();
        }
        [HttpGet]
        public IActionResult ChangeSuccess()
        {
            return View();
        }
        [HttpGet]
        public IActionResult ChangeEmail()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangeEmail(ChangeEmailViewModel model)
        {
            if (ModelState.IsValid)
            {
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                var user = await _context.Users.FindAsync(int.Parse(userId));

                if (user != null && user.Password == model.Password)
                {
                    user.Email = model.NewEmail;

                    if (await _context.Users.AnyAsync(u => u.Email == model.NewEmail && u.UserId != user.UserId))
                    {
                        ModelState.AddModelError("NewEmail", "This email is already in use.");
                        return View(model);
                    }

                    _context.Update(user);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = "The changes have been made successfully.";
                    return RedirectToAction("ChangeSuccess");
                }
                else
                {
                    ModelState.AddModelError("", "Incorrect password.");
                }
            }

            return View(model);
        }

        [HttpGet]
        public IActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            if (ModelState.IsValid)
            {
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                var user = await _context.Users.FindAsync(int.Parse(userId));

                if (user != null && user.Password == model.CurrentPassword)
                {
                    user.Password = model.NewPassword;
                    _context.Update(user);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = "The changes have been made successfully.";
                    return RedirectToAction("ChangeSuccess");
                }
                else
                {
                    ModelState.AddModelError("", "Current password is incorrect.");
                }
            }

            return View(model);
        }



        [HttpGet]
        public async Task<IActionResult> IsEmailInUse(string email)
        {
            var emailExists = await _context.Users.AnyAsync(u => u.Email == email);
            return Json(!emailExists);
        }
    }
}