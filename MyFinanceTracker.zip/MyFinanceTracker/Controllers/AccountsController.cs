﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyFinanceTracker.Models;
using System.Threading.Tasks;

namespace MyFinanceTracker.Controllers
{
    public class AccountsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccountsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var userId = GetUserId();
            var accounts = await _context.Accounts
                .Where(a => a.UserId == userId)
                .ToListAsync();
            return View(accounts);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View(new Account());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Account account)
        {
            var userId = GetUserId();
            ModelState.Remove("User");

            if (ModelState.IsValid)
            {
                account.UserId = userId;
                account.Balance = 0;
                _context.Add(account);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(account);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var account = await _context.Accounts
                .Include(a => a.Transactions)
                .Include(a => a.Goals)
                .FirstOrDefaultAsync(a => a.AccountId == id && a.UserId == GetUserId());

            if (account == null)
            {
                return NotFound("The Account was not found or the user does not have permission.");
            }


            _context.Transactions.RemoveRange(account.Transactions);
            _context.Goals.RemoveRange(account.Goals);

            var investments = await _context.Investments
                .Where(i => i.AccountId == id)
                .ToListAsync();

            foreach (var investment in investments)
            {
                investment.AccountId = null;
                _context.Investments.Update(investment);
            }


            _context.Accounts.Remove(account);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        [NonAction]
        private int GetUserId()
        {
            var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(userIdClaim))
            {
                throw new InvalidOperationException("The User ID claim not found or user is not authenticated.");
            }

            if (int.TryParse(userIdClaim, out int userId))
            {
                return userId;
            }
            else
            {
                throw new InvalidOperationException("The User ID claim not found or invalid.");
            }
        }
    }
}