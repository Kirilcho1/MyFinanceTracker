﻿using MyFinanceTracker.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace MyFinanceTracker.Controllers
{
    public class DashboardController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DashboardController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var userId = GetUserId();
            if (userId == -1)
            {
                return RedirectToAction("Login", "User");
            }

            var transactions = await _context.Transactions
                .Include(t => t.Category)
                .Where(t => t.UserId == userId)
                .ToListAsync();

            var investments = await _context.Investments
                .Include(i => i.Account)
                .Where(i => i.UserId == userId)
                .ToListAsync();

            var cultureInfo = new CultureInfo("en-GB")
            {
                NumberFormat = { CurrencySymbol = "$" }
            };

            var totalIncome = transactions
                .Where(t => t.Category != null && t.Category.Type == "Income")
                .Sum(t => (decimal?)t.Amount) ?? 0;

            var totalExpense = transactions
                .Where(t => t.Category != null && t.Category.Type == "Expense")
                .Sum(t => (decimal?)t.Amount) ?? 0;

            var totalInvestments = investments.Sum(i => (decimal?)i.CurrentAmount) ?? 0;
            totalExpense += totalInvestments;

            var balance = totalIncome - totalExpense;

            ViewData["TotalIncome"] = totalIncome.ToString("C0", cultureInfo);
            ViewData["TotalExpense"] = totalExpense.ToString("C0", cultureInfo);
            ViewData["Balance"] = balance < 0
                ? "-" + Math.Abs(balance).ToString("C0", cultureInfo)
                : balance.ToString("C0", cultureInfo);

            ViewBag.DonutChartData = transactions
                .Where(i => i.Category.Type == "Expense")
                .GroupBy(j => j.Category.CategoryId)
                .Select(k => new
                {
                    CategoryTitleWithIcon = k.First().Category.Title,
                    Amount = k.Sum(j => j.Amount),
                    formattedAmount = k.Sum(j => j.Amount).ToString("C0", cultureInfo),
                })
                .OrderByDescending(l => l.Amount)
                .ToList();

            var currentYear = DateTime.Now.Year;
            var months = Enumerable.Range(1, 12).Select(m => new DateTime(currentYear, m, 1).ToString("MMM-yyyy")).ToList();

            List<SplineChartData> IncomeSummary = transactions
                .Where(i => i.Category.Type == "Income")
                .GroupBy(j => j.Date.ToString("MMM-yyyy"))
                .Select(k => new SplineChartData()
                {
                    month = k.Key,
                    income = k.Sum(l => l.Amount)
                })
                .ToList();

            List<SplineChartData> ExpenseSummary = transactions
                .Where(i => i.Category.Type == "Expense")
                .GroupBy(j => j.Date.ToString("MMM-yyyy"))
                .Select(k => new SplineChartData()
                {
                    month = k.Key,
                    expense = k.Sum(l => l.Amount)
                })
                .ToList();

            foreach (var investment in investments)
            {
                var monthYear = investment.CreatedAt.ToString("MMM-yyyy");
                var expense = ExpenseSummary.FirstOrDefault(e => e.month == monthYear);
                if (expense != null)
                {
                    expense.expense += (int)investment.CurrentAmount;
                }
                else
                {
                    ExpenseSummary.Add(new SplineChartData { month = monthYear, expense = (int)investment.CurrentAmount });
                }
            }

            var splineChartData = from month in months
                                  join income in IncomeSummary on month equals income.month into incomeJoined
                                  from income in incomeJoined.DefaultIfEmpty()
                                  join expense in ExpenseSummary on month equals expense.month into expenseJoined
                                  from expense in expenseJoined.DefaultIfEmpty()
                                  select new
                                  {
                                      month = month,
                                      income = income?.income ?? 0,
                                      expense = expense?.expense ?? 0,
                                  };

            ViewBag.SplineChartData = splineChartData.OrderBy(d => DateTime.ParseExact(d.month, "MMM-yyyy", null)).ToList();

            ViewBag.RecentTransactions = await _context.Transactions
                .Include(i => i.Category)
                .Where(t => t.UserId == userId)
                .OrderByDescending(j => j.Date)
                .Take(5)
                .ToListAsync();

            return View(transactions);
        }

        [NonAction]
        private int GetUserId()
        {
            var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(userIdClaim))
            {
                Response.Redirect("/User/Login");
                return -1;
            }
            else
            {
                return int.Parse(userIdClaim);
            }
        }
    }

    public class SplineChartData
    {
        public string month { get; set; }
        public decimal income { get; set; }
        public decimal expense { get; set; }
    }
}