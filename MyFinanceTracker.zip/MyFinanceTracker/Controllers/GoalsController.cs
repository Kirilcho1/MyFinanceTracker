﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyFinanceTracker.Models;
using MyFinanceTracker.Models.DataTransferObjects;
using System.Globalization;


namespace MyFinanceTracker.Controllers
{
    public class GoalsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public GoalsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var cultureInfo = new CultureInfo("en-GB")
            {
                NumberFormat = { CurrencySymbol = "$" }
            };

            var goals = _context.Goals
      .Include(g => g.Account)
      .Select(g => new GoalDTO
      {
          GoalId = g.GoalId,
          Name = g.Name,
          TargetAmount = g.TargetAmount,
          CurrentAmount = g.CurrentAmount,
          GoalType = g.GoalType,
          AccountName = g.Account.Name,
          StartDate = g.StartDate,
          EndDate = g.EndDate,
          TargetAmountWithCurrency = g.TargetAmount.ToString("C0", cultureInfo),
          CurrentAmountWithCurrency = g.CurrentAmount.ToString("C0", cultureInfo)
      }).ToList();



            return View(goals);
        }

        [HttpGet]
        public IActionResult Create()
        {
            PopulateAccounts();
            return View(new Goal());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Goal goal)
        {
            var userId = GetUserId();
            goal.UserId = userId;

            if (goal.StartDate == DateTime.MinValue || goal.EndDate == DateTime.MinValue)
            {
                ModelState.AddModelError("DateError", "Please provide valid start and end dates.");
                PopulateAccounts();
                return View(goal);
            }

            var account = await _context.Accounts
                .FirstOrDefaultAsync(a => a.AccountId == goal.AccountId && a.UserId == userId);

            if (account == null)
            {
                ModelState.AddModelError("AccountId", "The Account is not found or does not belong to the user.");
                PopulateAccounts();
                return View(goal);
            }

            var existingGoal = await _context.Goals
                .FirstOrDefaultAsync(g => g.AccountId == goal.AccountId
                                           && g.GoalType == goal.GoalType
                                           && g.UserId == userId);

            if (existingGoal != null)
            {
                var errorModel = new ErrorViewModel
                {
                    Message = $"A goal of type '{goal.GoalType}' already exists for the selected account."
                };
                return View("Errors", errorModel);
            }

            if (goal.TargetAmount <= 0)
            {
                ModelState.AddModelError("TargetAmount", "The Target amount must be greater than zero.");
                PopulateAccounts();
                return View(goal);
            }

            goal.CurrentAmount = 0;

            try
            {
                _context.Goals.Add(goal);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                var errorModel = new ErrorViewModel
                {
                    Message = $"An error occurred while saving the goal: {ex.Message}"
                };
                return View("Errors", errorModel);
            }
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var goal = await _context.Goals
                .Include(g => g.Account)
                .Include(g => g.Transactions)
                .FirstOrDefaultAsync(g => g.GoalId == id && g.UserId == GetUserId());

            if (goal == null)
            {
                return NotFound("The Goal is not found or user does not have permission.");
            }

            _context.Goals.Remove(goal);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index", "Goals");
        }

        private void PopulateAccounts()
        {
            var userId = GetUserId();
            var accounts = _context.Accounts
                .Where(a => a.UserId == userId)
                .ToList();

            Account defaultAccount = new Account
            {
                AccountId = 0,
                Name = "Choose an Account"
            };

            accounts.Insert(0, defaultAccount);
            ViewBag.Accounts = accounts;
        }

        [NonAction]
        private int GetUserId()
        {
            var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(userIdClaim))
            {
                throw new InvalidOperationException("The User ID claim not found or user is not authenticated.");
            }

            if (int.TryParse(userIdClaim, out int userId))
            {
                return userId;
            }
            else
            {
                throw new InvalidOperationException("The User ID claim not found or invalid.");
            }
        }
    }
}