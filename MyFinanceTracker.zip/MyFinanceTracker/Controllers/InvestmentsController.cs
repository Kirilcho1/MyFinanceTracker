﻿using MyFinanceTracker.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace MyFinanceTracker.Controllers
{
    public class InvestmentsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public InvestmentsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var userId = GetUserId();
            var investments = await _context.Investments
                .Include(i => i.Account)
                .Where(i => i.UserId == userId)
                .ToListAsync();

            return View(investments);
        }

        public IActionResult Create()
        {
            PopulateAccounts();
            var investment = new Investment
            {
                CreatedAt = DateTime.Now
            };
            return View(investment);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Investment investment)
        {
            var userId = GetUserId();
            investment.UserId = userId;

            if (investment.CreatedAt == DateTime.MinValue)
            {
                investment.CreatedAt = DateTime.Now;
            }

            var account = await _context.Accounts
                .FirstOrDefaultAsync(a => a.AccountId == investment.AccountId && a.UserId == userId);

            if (account == null)
            {
                ModelState.AddModelError("AccountId", "The Account is not found or does not belong to the user.");
                PopulateAccounts();
                return View(investment);
            }

            if (investment.CurrentAmount <= 0)
            {
                ModelState.AddModelError("CurrentAmount", "The Investment amount must be greater than zero.");
                PopulateAccounts();
                return View(investment);
            }

            if (account.Balance < investment.CurrentAmount)
            {
                ModelState.AddModelError("CurrentAmount", "Not enough balance in the account.");
                PopulateAccounts();
                return View(investment);
            }

            account.Balance -= investment.CurrentAmount;

            _context.Accounts.Update(account);
            _context.Investments.Add(investment);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var investment = await _context.Investments
                .Include(i => i.Account)
                .FirstOrDefaultAsync(i => i.InvestmentId == id);

            if (investment == null)
            {
                return NotFound();
            }

            PopulateAccounts();
            return View(investment);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Investment investment)
        {
            if (id != investment.InvestmentId)
            {
                return NotFound();
            }

            var existingInvestment = await _context.Investments
                .Include(i => i.Account)
                .FirstOrDefaultAsync(i => i.InvestmentId == id);

            if (existingInvestment == null)
            {
                return NotFound();
            }

            investment.CreatedAt = existingInvestment.CreatedAt;

            var account = await _context.Accounts.FirstOrDefaultAsync(a => a.AccountId == investment.AccountId);

            if (account == null)
            {
                ModelState.AddModelError("", "The associated account has been deleted. Please select a new account.");
                PopulateAccounts();
                return View(investment);
            }

            var difference = investment.CurrentAmount - existingInvestment.CurrentAmount;

            if (difference > 0 && account.Balance < difference)
            {
                ModelState.AddModelError("CurrentAmount", "Not enough balance in the account to increase the investment.");
                PopulateAccounts();
                return View(investment);
            }

            account.Balance -= difference;

            _context.Accounts.Update(account);

            existingInvestment.CurrentAmount = investment.CurrentAmount;
            existingInvestment.AccountId = investment.AccountId;

            _context.Investments.Update(existingInvestment);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var investment = await _context.Investments
                .Include(i => i.Account)
                .FirstOrDefaultAsync(i => i.InvestmentId == id && i.UserId == GetUserId());

            if (investment == null)
            {
                return NotFound("The investment is not found or user does not have permission.");
            }

            var account = investment.Account;

            if (account != null && investment.CurrentAmount != investment.TargetAmount)
            {
                account.Balance += investment.CurrentAmount;
                _context.Accounts.Update(account);
            }

            _context.Investments.Remove(investment);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private void PopulateAccounts()
        {
            var userId = GetUserId();
            ViewBag.Accounts = _context.Accounts
                .Where(a => a.UserId == userId)
                .ToList();
        }

        [NonAction]
        private int GetUserId()
        {
            var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(userIdClaim))
            {
                throw new InvalidOperationException("User is not logged in.");
            }
            else
            {
                return int.Parse(userIdClaim);
            }
        }

    }
}